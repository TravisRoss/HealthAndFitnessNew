package com.example.healthandfitnessnew;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button btnGoals, btnUserInfo, btnLogbook, btnHistory;

        btnGoals = findViewById(R.id.btnGoals);
        btnUserInfo = findViewById(R.id.btnUserInfo);
        btnLogbook = findViewById(R.id.btnLogbook);
        btnHistory = findViewById(R.id.btnHistory);

        btnGoals.setOnClickListener(this);
        btnUserInfo.setOnClickListener(this);
        btnLogbook.setOnClickListener(this);
        btnHistory.setOnClickListener(this);
    }


    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.btnGoals:
                //launch Goals page
                openGoalsActivity();
                break;
            case R.id.btnUserInfo:
                //launch progress page
                openUserInfoActivity();
                break;
            case R.id.btnLogbook:
                //launch logbook page
                openLogbookActivity();
                break;
            case R.id.btnHistory:
                //launch history page
                openHistoryActivity();
                break;
        }

    }

    //create three new activiers, copy the same layout into each.

    public void openGoalsActivity(){
        Intent intent = new Intent(this, GoalsActivity.class);
        startActivity(intent);
    }

    public void openUserInfoActivity(){
        Intent intent = new Intent(this, UserInfoActivity.class);
        startActivity(intent);
    }

    public void openLogbookActivity(){
        Intent intent = new Intent(this, LogbookActivity.class);
        startActivity(intent);
    }

    public void openHistoryActivity(){
        Intent intent = new Intent(this, HistoryActivity.class);
        startActivity(intent);
    }
}

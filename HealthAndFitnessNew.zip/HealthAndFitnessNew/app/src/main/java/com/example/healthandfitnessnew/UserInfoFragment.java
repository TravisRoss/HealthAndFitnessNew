package com.example.healthandfitnessnew;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

public class UserInfoFragment extends Fragment {

    private static float mSeries = 0f;
    private static float mSeries1 = 0f;
    private static float mSeries2 = 0f;
    private static float mSeries3 = 0f;
    private static float mSeries4 = 0f;


    private int position;
    private DatabaseReference rDatabase;
    private FirebaseAuth mAuth;

    public UserInfoFragment() {
    }

    /*public static UserInfoFragment newInstance() {
        UserInfoFragment fragment = new UserInfoFragment();
        return fragment;
    }*/

    private DatabaseReference getUsersRef(String ref) {
        FirebaseUser user = mAuth.getCurrentUser();
        assert user != null;
        String userId = user.getUid();
        return rDatabase.child("Users").child(userId).child(ref);
    }

    @Override
    public void onCreate(Bundle s) {
        super.onCreate(s);
        mAuth = FirebaseAuth.getInstance();
        rDatabase = FirebaseDatabase.getInstance().getReference();
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        //declare view
        final View rootView = inflater.inflate(R.layout.activity_user_info_fragment, container, false);

        //set variables
        final Button btnHomeFromGoals = rootView.findViewById(R.id.homeButton);
        final Button save = rootView.findViewById(R.id.saveButton); //save user data and return to home page
        final EditText nameET = rootView.findViewById(R.id.nameInput);
        final EditText phoneET = rootView.findViewById(R.id.phoneInput);
        final EditText ageET = rootView.findViewById(R.id.ageInput);
        final EditText weightET = rootView.findViewById(R.id.weightInput);
        final EditText heightET = rootView.findViewById(R.id.heightInput);

        //RadioGroup contains two options: male or female.
        final RadioGroup myRadioGroup = rootView.findViewById(R.id.genderGroup);
        myRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                position = myRadioGroup.indexOfChild(rootView.findViewById(checkedId));
                if (position == 0) {
                    Log.d("Gender is ", "Male");
                    getUsersRef("gender").setValue("Male");
                } else {
                    Log.d("Gender is ", "Female");
                    getUsersRef("gender").setValue("Female");
                }
            }
        });//end myRadioGroup setOnCheckedChangeListener


        //on click listener to return home
        btnHomeFromGoals.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                returnToHomePage();
            }
        });



        //save user data to Firebase
        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (nameET.getText().toString().length() == 0) {
                    nameET.setError("Please enter your name.");
                    return;
                } else if (phoneET.getText().toString().length() == 0) {
                    phoneET.setError("Please enter your phone number.");
                    return;
                } else if (ageET.getText().toString().length() == 0) {
                    ageET.setError("Please enter your age.");
                    return;
                } else if (weightET.getText().toString().length() == 0) {
                    weightET.setError("Please enter your weight.");
                    return;
                } else if (heightET.getText().toString().length() == 0) {
                    heightET.setError("Please enter your height.");
                    return;
                }//end if statement

                //Set values on Firebase
                rDatabase.child("Users").child("User").child("Full Name").setValue(nameET.getText().toString());
                rDatabase.child("Users").child("User").child("Phone No.").setValue(phoneET.getText().toString());
                rDatabase.child("Users").child("User").child("Age (years)").setValue(ageET.getText().toString());
                rDatabase.child("Users").child("User").child("Weight (lbs)").setValue(weightET.getText().toString());
                rDatabase.child("Users").child("User").child("Height (cm)").setValue(heightET.getText().toString());

                rDatabase.child("Users").child("User").child("Full Name").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        mSeries = Float.parseFloat(String.valueOf(dataSnapshot.getValue()));
                        Log.d("mSeries", (String.valueOf(mSeries)));
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                    }
                });//end full name child

                rDatabase.child("Users").child("User").child("Phone No.").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        mSeries1 = Float.parseFloat(String.valueOf(dataSnapshot.getValue()));
                        Log.d("mSeries1", (String.valueOf(mSeries1)));
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                    }
                });//end phone no. child

                rDatabase.child("Users").child("User").child("Age").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        mSeries1 = Float.parseFloat(String.valueOf(dataSnapshot.getValue()));
                        Log.d("mSeries2", (String.valueOf(mSeries2)));
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                    }
                });//end age child

                rDatabase.child("Users").child("User").child("Weight").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        mSeries1 = Float.parseFloat(String.valueOf(dataSnapshot.getValue()));
                        Log.d("mSeries3", (String.valueOf(mSeries3)));
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                    }
                });//end weight child

                rDatabase.child("Users").child("User").child("Height").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {
                        mSeries1 = Float.parseFloat(String.valueOf(dataSnapshot.getValue()));
                        Log.d("mSeries4", (String.valueOf(mSeries4)));
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {
                    }
                });//end height child

                returnToHomePage();

            }//end onClick

        });//end onClickListener

        return rootView;

    }//end onCreateView

    private void returnToHomePage() {
        Intent intent = new Intent(getContext(), MainActivity.class);
        startActivity(intent);
    }

}//end class

